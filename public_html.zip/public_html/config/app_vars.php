<?php
return array (
  'Adlinkfly' => 
  array (
    'installed' => 1,
  ),
);